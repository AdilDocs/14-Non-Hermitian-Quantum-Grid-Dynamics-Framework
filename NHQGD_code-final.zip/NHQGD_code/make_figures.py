"""Publication figures from results/ (run after validate.py, run_scaling.py, extra_experiments.py)."""
import json, pickle, os
import numpy as np, pandas as pd, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
import scipy.sparse.linalg as spla
from sklearn.isotonic import IsotonicRegression

C = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100"]; INK, MUTED, GRID = "#000000", "#000000", "#e4e3dc"
plt.rcParams.update({"font.family": "serif", "font.size": 9, "text.color": "#000000", "axes.titlecolor": "#000000", "legend.labelcolor": "#000000", "axes.linewidth": 0.9, "axes.edgecolor": MUTED, "axes.labelcolor": INK,
                     "xtick.color": MUTED, "ytick.color": MUTED, "axes.spines.top": False,
                     "axes.spines.right": False, "legend.frameon": False})
CASES = [("case24_ieee_rts", "IEEE 24-bus"), ("case118", "IEEE 118-bus")]
CASES = [c for c in CASES if os.path.exists(f"results/hourly_{c[0]}.csv")]
os.makedirs("results/figs", exist_ok=True)


def save(fig, name):
    fig.tight_layout(); fig.savefig(f"results/figs/{name}.png", dpi=300); fig.savefig(f"results/figs/{name}.pdf"); plt.close(fig)


def grid_ax(a, axis="both"):
    a.grid(True, axis=axis, color=GRID, lw=0.6); a.set_axisbelow(True)


# ---------------- Fig: indicator vs benchmark scatter ----------------
fig, ax = plt.subplots(1, len(CASES), figsize=(3.6 * len(CASES), 3.0), squeeze=False); ax = ax[0]
for a, (c, lab) in zip(ax, CASES):
    h = pd.read_csv(f"results/hourly_{c}.csv"); y = h.EENS_tot.clip(lower=1e-3)
    tr = np.arange(len(h)) % 2 == 0
    a.scatter(h.D[tr], y[tr], s=9, color=C[0], alpha=0.5, edgecolor="none", label="training hours")
    a.scatter(h.D[~tr], y[~tr], s=9, color=C[1], alpha=0.5, edgecolor="none", label="test hours")
    a.set_xscale("log"); a.set_yscale("log"); grid_ax(a)
    v = pd.read_csv(f"results/validation_{c}.csv").iloc[0]
    a.set_title(f"{lab} (Spearman {v.rho_EENS_tot:.2f})", fontsize=9, color=INK)
    a.set_xlabel("Decay indicator $D(t)$"); a.set_ylabel("Benchmark EENS (MWh/h)")
    if (h.EENS_tot < 1e-3).any():
        a.text(0.02, 0.04, "EENS = 0 plotted at $10^{-3}$", transform=a.transAxes, color=MUTED, fontsize=7.5)
ax[0].legend(loc="upper left", fontsize=7.5)
save(fig, "fig_indicator_vs_benchmark")

# ---------------- Fig: ablation ----------------
V = [pd.read_csv(f"results/validation_{c}.csv") for c, _ in CASES]
names = V[0].variant.str.replace("BASELINE: ", "baseline: ").tolist()
yy = np.arange(len(names)); fig, a = plt.subplots(figsize=(7.2, 3.6)); w = 0.8 / len(V)
for k, (v, (_, lab)) in enumerate(zip(V, CASES)):
    a.barh(yy - 0.4 + w * (k + 0.5), v.spearman_test, height=w * 0.92, color=C[k], label=lab)
a.set_yticks(yy, names); a.invert_yaxis(); a.set_xlim(0, 1); grid_ax(a, "x")
a.set_xlabel("Held-out Spearman correlation with benchmark EENS")
a.legend(loc="lower center", bbox_to_anchor=(0.5, 1.0), ncol=len(V))
save(fig, "fig_ablation")

# ---------------- Fig: hyper-parameter sensitivity ----------------
fig, ax = plt.subplots(1, len(CASES), figsize=(3.6 * len(CASES), 3.0), squeeze=False, sharey=True); ax = ax[0]
for a, (c, lab) in zip(ax, CASES):
    S = pd.read_csv(f"results/hyper_search_{c}.csv"); sel = json.load(open(f"results/channels_{c}.json"))["selected_walk"]
    for k, J0 in enumerate(sorted(S.J0.unique())):
        s = S[(S.J0 == J0) & (S.tau == sel["tau"])].sort_values("mu_N")
        a.plot(s.mu_N, s.test, "-o", ms=3.5, lw=1.8, color=C[k], label=f"$J_0$ = {J0:g}")
    a.axvline(sel["mu_N"], color=MUTED, lw=0.8, ls="--")
    a.set_xscale("log"); grid_ax(a); a.set_title(f"{lab} ($\\tau$ = {sel['tau']:g})", fontsize=9, color=INK)
    a.set_xlabel("Network damping weight $\\mu_N$")
ax[0].set_ylabel("Held-out Spearman correlation"); ax[0].legend(loc="lower left", fontsize=7.5)
save(fig, "fig_sensitivity")

# ---------------- Fig: scaling ----------------
if os.path.exists("results/scaling.csv"):
    s = pd.read_csv("results/scaling.csv"); fig, a = plt.subplots(figsize=(4.6, 3.2))
    a.plot(s.N, s.walk_ms / 1e3, "-o", color=C[0], lw=2, ms=5)
    a.plot(s.N, s.classical_lower_bound_s, "-s", color=C[1], lw=2, ms=5)
    a.set_xscale("log"); a.set_yscale("log"); grid_ax(a)
    a.text(s.N.iloc[-1] * 0.9, s.walk_ms.iloc[-1] / 1e3 * 0.4, "proposed indicator", color=INK, ha="right")
    a.text(s.N.iloc[-1] * 0.9, s.classical_lower_bound_s.iloc[-1] * 1.7, "classical (lower bound)", color=INK, ha="right")
    a.set_xlabel("Number of buses"); a.set_ylabel("Runtime per hour (s)")
    save(fig, "fig_scaling")

# ---------------- extra (24-bus): convergence, week, norm decay ----------------
if os.path.exists("results/extra_case24.pkl"):
    X = pickle.load(open("results/extra_case24.pkl", "rb"))
    # MC convergence: relative 95% CI half-width vs N
    fig, a = plt.subplots(figsize=(4.6, 3.2))
    for k, (name, x) in enumerate(X["conv"].items()):
        n = np.arange(1, len(x) + 1); m = np.cumsum(x) / n
        sd = np.sqrt(np.maximum(np.cumsum(x ** 2) / n - m ** 2, 0))
        rel = np.where(m > 0, 1.96 * sd / np.sqrt(n) / np.maximum(m, 1e-12), np.nan)
        idx = np.unique(np.logspace(1, np.log10(len(x)), 120).astype(int)) - 1
        a.plot(n[idx], rel[idx], color=C[k], lw=1.8)
        a.text(n[idx][-1] * 1.05, rel[idx][-1], f"{name} risk", color=INK, va="center", fontsize=8)
    a.axvline(4000, color=MUTED, lw=0.8, ls="--"); a.text(4000 * 0.92, 0.06, "$N_s$ = 4000", color=MUTED, fontsize=8, ha="right")
    a.set_xscale("log"); a.set_yscale("log"); grid_ax(a); a.set_xlim(10, 20000 * 4)
    a.set_xlabel("Number of MCS samples"); a.set_ylabel("Relative 95% CI half-width of EENS")
    save(fig, "fig_mc_convergence")

    # week time series
    w = pd.DataFrame(X["week"]); h = pd.read_csv("results/hourly_case24_ieee_rts.csv"); tr = np.arange(len(h)) % 2 == 0
    iso = IsotonicRegression(out_of_bounds="clip").fit(h.D[tr], h.EENS_tot[tr]); w["pred"] = iso.predict(w.D)
    x = np.arange(len(w))
    fig, ax = plt.subplots(3, 1, figsize=(7.2, 5.4), sharex=True)
    ax[0].plot(x, w.net, color=MUTED, lw=1.6); ax[0].set_ylabel("Net load (MW)"); grid_ax(ax[0])
    ax[1].plot(x, w.EENS, color=C[0], lw=1.8, label="benchmark (MCS + cascade)")
    ax[1].plot(x, w.pred, color=C[1], lw=1.6, ls="--", label="proposed (calibrated $g(D)$)")
    ax[1].set_ylabel("EENS (MWh/h)"); ax[1].legend(loc="upper right", fontsize=7.5); grid_ax(ax[1])
    ax[2].stackplot(x, w.DA, w.DN, colors=[C[2], C[3]], labels=["adequacy share $D_A$", "network share $D_N$"], edgecolor="white", lw=0.4)
    ax[2].set_ylabel("Norm loss"); ax[2].legend(loc="upper right", fontsize=7.5); grid_ax(ax[2])
    ax[2].set_xlabel(f"Hour of week (starting {X['ts'][:10]})"); ax[2].set_xticks(range(0, 169, 24))
    save(fig, "fig_week_timeseries")

    # norm decay curves (Proposition 1)
    from grid import Grid; from data import load_opsd, Profiles; from walk import Walk
    g = Grid("case24_ieee_rts", reserve_margin=0.0); P = Profiles(g, load_opsd())
    sel = json.load(open("results/channels_case24_ieee_rts.json"))["selected_walk"]; W = Walk(g, **sel)
    q = h.sort_values("D"); picks = {"low": int(q.t.iloc[len(q) // 10]), "medium": int(q.t.iloc[len(q) // 2]), "high": int(q.t.iloc[-1])}
    fig, a = plt.subplots(figsize=(4.6, 3.2)); smax = 3 * sel["tau"]
    for k, (name, t) in enumerate(picks.items()):
        H, psi0, gam, *_ = W.operator(*P.hour(t))
        traj = spla.expm_multiply(-1j * H, psi0, start=0, stop=smax, num=121, endpoint=True)
        ss = np.linspace(0, smax, 121); Ps = (np.abs(traj) ** 2).sum(1)
        a.plot(ss, Ps, color=C[k], lw=1.9, label=f"{name} stress")
        a.plot(ss, np.exp(-2 * gam.max() * ss), color=C[k], lw=0.9, ls=":")
    a.axvline(sel["tau"], color=MUTED, lw=0.8, ls="--"); a.text(sel["tau"] * 1.03, 0.04, "$\\tau$", color=MUTED)
    a.set_ylim(0, 1.03); a.set_xlim(0, smax); grid_ax(a)
    a.set_xlabel("Walk pseudo-time $s$"); a.set_ylabel("Survival probability $P_{surv}(s)$")
    a.legend(loc="lower left", fontsize=7.5); a.text(0.98, 0.97, "dotted: lower bound $e^{-2\\gamma_{max}s}$", transform=a.transAxes,
                                                   ha="right", va="top", fontsize=7.5, color=MUTED)
    save(fig, "fig_norm_decay")
print("figures written to results/figs")
