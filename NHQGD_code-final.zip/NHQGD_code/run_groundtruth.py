"""Classical ground truth for a set of hours (parallel). Saves results/gt_<case>.pkl
usage: python run_groundtruth.py <case> <hour_step> <Ns> [workers]"""
import numpy as np, time, sys, os, pickle
from multiprocessing import Pool
CFG = dict(reserve_margin=0.0, trip_factor=1.2, beta=9.0, seed=0)
_G = {}

def _init(case, Ns):
    from grid import Grid; from data import load_opsd, Profiles
    g = Grid(case, reserve_margin=CFG["reserve_margin"]); P = Profiles(g, load_opsd())
    _G.update(g=g, P=P, U=np.random.default_rng(CFG["seed"]).random((Ns, g.G)))

def _work(t):
    from classical import evaluate_hour
    g, P, U = _G["g"], _G["P"], _G["U"]
    L, R, cw = P.hour(t); th = time.perf_counter()
    r = evaluate_hour(g, L, R, cw, U, beta=CFG["beta"], trip_factor=CFG["trip_factor"])
    r["t"] = int(t); r["sec"] = time.perf_counter() - th
    return r

if __name__ == "__main__":
    case, step, Ns = sys.argv[1], int(sys.argv[2]), int(sys.argv[3])
    nw = int(sys.argv[4]) if len(sys.argv) > 4 else os.cpu_count()
    os.makedirs("results", exist_ok=True)
    hours = list(range(0, 8760, step)); t0 = time.time(); rows = []
    with Pool(nw, initializer=_init, initargs=(case, Ns)) as pool:
        for j, r in enumerate(pool.imap(_work, hours)):
            rows.append(r)
            if j % 25 == 0: print(case, j, len(hours), "%.0fs" % (time.time() - t0), flush=True)
    pickle.dump(dict(rows=rows, cfg=CFG, Ns=Ns, case=case), open(f"results/gt_{case}.pkl", "wb"))
    print("done", time.time() - t0)
