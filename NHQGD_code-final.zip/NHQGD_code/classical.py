"""
classical.py - Independent classical ground truth.

(1) Generation-adequacy channel: sequential-state-free (non-sequential) Monte
    Carlo over unit states s_g ~ Bernoulli(A_g); each state is dispatched by a
    DC optimal power flow with load shedding (line limits enforced).
(2) Cascading channel: on the intact-system dispatch, every single branch
    contingency k is simulated with a DC cascade model (flow redistribution ->
    overload tripping above trip_factor * rating -> islanding -> island
    re-balancing / load shedding -> repeat).

Nothing here uses the walk indicator, and the walk never uses these results.
"""
import numpy as np
from scipy.optimize import linprog
from scipy.sparse.csgraph import connected_components
import scipy.sparse as sp

VOLL = 1e4


def dispatch_lp(g, L, R, cap):
    """DC-OPF with load shedding (sparse B-theta form). Returns (pg_units, shed_bus, curt_bus)."""
    G, N, Lb = g.G, g.N, g.L
    lb_i = np.where(L > 1e-9)[0]; rb_i = np.where(R > 1e-9)[0]
    nS, nC = len(lb_i), len(rb_i)
    # vars: pg (G) | shed (nS) | curt (nC) | theta (N)
    nv = G + nS + nC + N
    Ag = sp.csr_matrix((np.ones(G), (g.ubus, np.arange(G))), shape=(N, G))
    As = sp.csr_matrix((np.ones(nS), (lb_i, np.arange(nS))), shape=(N, nS))
    Ac = sp.csr_matrix((-np.ones(nC), (rb_i, np.arange(nC))), shape=(N, nC))
    B, Bf = g.Bbus()
    # balance: Ag pg + As shed + Ac curt - B theta = L - R
    A_eq = sp.hstack([Ag, As, Ac, -B]).tocsr()
    b_eq = L - R
    # reference angle
    ref = sp.csr_matrix(([1.0], ([0], [G + nS + nC + g.ref])), shape=(1, nv))
    A_eq = sp.vstack([A_eq, ref]).tocsr(); b_eq = np.r_[b_eq, 0.0]
    Z = sp.csr_matrix((Lb, G + nS + nC))
    A_ub = sp.vstack([sp.hstack([Z, Bf]), sp.hstack([Z, -Bf])]).tocsr()
    b_ub = np.r_[g.F, g.F]
    c = np.r_[g.ucost, np.full(nS, VOLL), np.full(nC, 0.01), np.zeros(N)]
    bounds = np.r_[np.c_[np.zeros(G), cap], np.c_[np.zeros(nS), L[lb_i]],
                   np.c_[np.zeros(nC), R[rb_i]], np.c_[np.full(N, -np.inf), np.full(N, np.inf)]]
    res = linprog(c, A_ub=A_ub, b_ub=b_ub, A_eq=A_eq, b_eq=b_eq, bounds=bounds, method="highs")
    if res.status != 0:
        res = linprog(c, A_eq=A_eq, b_eq=b_eq, bounds=bounds, method="highs")
    x = res.x
    shed = np.zeros(N); shed[lb_i] = x[G:G + nS]
    curt = np.zeros(N); curt[rb_i] = x[G + nS:G + nS + nC]
    return x[:G], shed, curt


def cascade(g, pg, cap, Lserved, Rused, k, trip_factor=1.0, max_iter=50):
    """DC cascade after outage of branch k. Returns (extra shed MW, #branches tripped)."""
    alive = np.ones(g.L, bool); alive[k] = False
    pg = pg.copy(); Lb = Lserved.copy(); Rb = Rused.copy()
    L0 = Lb.sum(); ntrip = 1
    for _ in range(max_iter):
        A = sp.csr_matrix((np.ones(alive.sum()), (g.fr[alive], g.to[alive])), shape=(g.N, g.N))
        nc, lab = connected_components(A, directed=False)
        ulab = lab[g.ubus]
        for c in range(nc):
            nodes = lab == c
            units = ulab == c
            gen = pg[units].sum() + Rb[nodes].sum()
            dem = Lb[nodes].sum()
            if gen > dem + 1e-6:                       # surplus: back down units, then curtail RES
                cut = gen - dem
                pgc = pg[units].sum()
                if pgc > 0:
                    s = min(cut, pgc); pg[units] *= (1 - s / pgc); cut -= s
                if cut > 1e-9:
                    Rb[nodes] *= max(0.0, 1 - cut / max(Rb[nodes].sum(), 1e-9))
            elif dem > gen + 1e-6:                     # deficit: ramp headroom, then shed
                need = dem - gen
                head = (cap - pg)[units]
                h = head.sum()
                if h > 0:
                    s = min(need, h); pg[units] += head * (s / h); need -= s
                if need > 1e-9:
                    Lb[nodes] *= max(0.0, 1 - need / dem)
        inj = -Lb + Rb
        np.add.at(inj, g.ubus, pg)
        f, _, _ = g.dc_flows_topology(inj, alive)
        over = alive & (np.abs(f) > trip_factor * g.F * (1 + 1e-6))
        if not over.any():
            break
        alive &= ~over
        ntrip += int(over.sum())
    return L0 - Lb.sum(), ntrip, (Lserved - Lb)


class HourResult(dict):
    pass


def evaluate_hour(g, L, R, cf_w, U, beta=9.0, trip_factor=1.0, do_cascade=True):
    """Ground truth for one hour. U: (Ns, G) common random numbers."""
    Ns = U.shape[0]
    avail = U < g.uA[None, :]
    # ---------- (1) generation adequacy MC with exact zero-shed shortcut ----------
    pg0, shed0, curt0 = dispatch_lp(g, L, R, g.upmax)
    supports = [pg0 > 1e-6] if shed0.sum() < 1e-6 else []
    cache = {}
    shed_tot = np.zeros(Ns); node_shed = np.zeros(g.N); n_lp = 1
    for s in range(Ns):
        a = avail[s]
        if any(not np.any(sup & ~a) for sup in supports):
            continue                                   # a known zero-shed dispatch is still feasible
        key = a.tobytes()
        if key not in cache:
            pg, sh, _ = dispatch_lp(g, L, R, g.upmax * a); n_lp += 1
            cache[key] = sh
            if sh.sum() < 1e-6 and len(supports) < 64:
                supports.append(pg > 1e-6)
        sh = cache[key]
        shed_tot[s] = sh.sum(); node_shed += sh
    res = HourResult(LOLP_gen=float((shed_tot > 1e-3).mean()),
                     EENS_gen=float(shed_tot.mean()),            # MWh in this 1-h interval
                     node_EENS_gen=node_shed / Ns, n_lp=n_lp)
    # ---------- (2) cascading channel on intact dispatch ----------
    if do_cascade:
        lam_h = g.lam_line * (1 + beta * cf_w ** 2) / 8760.0     # per-hour trip probability
        ens_k = np.zeros(g.L); trips_k = np.zeros(g.L); node_c = np.zeros(g.N)
        Lserved = L - shed0; Rused = R - curt0
        for k in range(g.L):
            e, n, nodeloss = cascade(g, pg0, g.upmax, Lserved, Rused, k, trip_factor)
            ens_k[k] = e; trips_k[k] = n; node_c += lam_h[k] * nodeloss
        pi = lam_h / lam_h.sum()
        res.update(CS=float(pi @ ens_k),                          # expected ENS | one contingency
                   EENS_casc=float(lam_h @ ens_k),
                   LOLP_casc=float(lam_h @ (ens_k > 1e-3)),
                   mean_trips=float(pi @ trips_k), max_ens_k=float(ens_k.max()),
                   ens_k=ens_k, node_EENS_casc=node_c)
    res["EENS_tot"] = res["EENS_gen"] + res.get("EENS_casc", 0.0)
    return res
