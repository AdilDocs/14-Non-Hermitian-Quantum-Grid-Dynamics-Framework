#!/bin/sh
# Full NHQGD pipeline. Run from this folder after placing the OPSD file in data/ (see README).
# Approximate runtime on a 2-core machine: ~1.5 h.
set -e
python run_groundtruth.py case24_ieee_rts 13 4000   # 674 hours, Ns = 4000
python run_groundtruth.py case118 29 1000           # 303 hours, Ns = 1000
python run_groundtruth.py case300 43 500            # 204 hours, Ns = 500
python validate.py case24_ieee_rts
python validate.py case118
python validate.py case300
python combined_baseline.py
python extra_experiments.py                         # MC convergence + highest net-load week (24-bus)
python run_scaling.py                               # runtime, 24 ... 2869 buses
python make_figures.py                              # results figures
python fig_setup.py                                 # setup figures (networks, OPSD, benchmark risk)
