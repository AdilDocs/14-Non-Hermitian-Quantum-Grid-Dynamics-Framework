"""
run_scaling.py - Runtime vs network size (24 ... 2869 buses).

Walk indicator: measured per hour (stress build incl. N-1 LODF screen + sparse
expm_multiply), plus one-off setup (PTDF/LODF).
Classical: measured time per dispatch LP and per cascade simulation. The
reported classical per-hour cost is a LOWER BOUND = 1 LP + L cascade runs
(i.e. the cascading channel alone, ignoring all Monte Carlo LP solves), so the
speed-up figures are conservative.
"""
import time, json, sys
import numpy as np, pandas as pd
from grid import Grid
from data import load_opsd, Profiles
from walk import Walk
from classical import dispatch_lp, cascade

CASES = sys.argv[1:] or ["case24_ieee_rts", "case39", "case57", "case118", "case300",
                         "case1354pegase", "case2869pegase"]
d = load_opsd()
rng = np.random.default_rng(0)
hours = rng.choice(8760, 12, replace=False)
rows = []
for case in CASES:
    t0 = time.perf_counter()
    g = Grid(case, reserve_margin=0.0); P = Profiles(g, d)
    setup = time.perf_counter() - t0
    W = Walk(g)
    tw = []; tsp = []
    for t in hours:
        L, R, cw = P.hour(t)
        a = time.perf_counter(); W.run(L, R, cw, fast=True); tw.append(time.perf_counter() - a)
    for t in hours[:3]:
        L, R, cw = P.hour(t)
        a = time.perf_counter(); W.run(L, R, cw, spectral=True); tsp.append(time.perf_counter() - a)
    # classical unit costs
    tl, tc = [], []
    for t in hours[:3]:
        L, R, cw = P.hour(t)
        a = time.perf_counter(); pg, sh, cu = dispatch_lp(g, L, R, g.upmax); tl.append(time.perf_counter() - a)
        ks = rng.choice(np.where(~g.radial)[0], min(8, g.L), replace=False)
        for k in ks:
            a = time.perf_counter(); cascade(g, pg, g.upmax, L - sh, R - cu, k, 1.2)
            tc.append(time.perf_counter() - a)
    t_lp, t_c = float(np.mean(tl)), float(np.mean(tc))
    lb = t_lp + g.L * t_c
    rec = dict(case=case, N=g.N, L=g.L, units=g.G, setup_s=setup,
               walk_ms=1e3 * np.median(tw), walk_spectral_ms=1e3 * np.median(tsp),
               lp_ms=1e3 * t_lp, cascade_ms=1e3 * t_c,
               classical_lower_bound_s=lb, speedup_vs_lower_bound=lb / np.median(tw))
    rows.append(rec); print({k: (round(v, 3) if isinstance(v, float) else v) for k, v in rec.items()}, flush=True)
pd.DataFrame(rows).to_csv("results/scaling.csv", index=False)
