"""
validate.py - Independent validation of the NH-walk indicator against the
classical Monte Carlo / cascade ground truth, plus ablations.

usage: python validate.py <case>
"""
import sys, pickle, json, time
import numpy as np, pandas as pd
from scipy.stats import spearmanr, norm
from sklearn.isotonic import IsotonicRegression
from grid import Grid
from data import load_opsd, Profiles
from walk import Walk

case = sys.argv[1] if len(sys.argv) > 1 else "case24_ieee_rts"
gt = pickle.load(open(f"results/gt_{case}.pkl", "rb"))
cfg = gt["cfg"]
g = Grid(case, reserve_margin=cfg["reserve_margin"]); P = Profiles(g, load_opsd())
rows = gt["rows"]; hours = np.array([r["t"] for r in rows])
T = pd.DataFrame({k: [r[k] for r in rows] for k in
                  ["t", "LOLP_gen", "EENS_gen", "CS", "EENS_casc", "EENS_tot", "mean_trips", "sec"]})

VARIANTS = {
    "walk (full)":            dict(),
    "no hopping (J=0)":       dict(use_J=False),
    "uniform psi(0)":         dict(init="uniform"),
    "adequacy term only":     dict(mu_N=0.0),
    "network term only":      dict(mu_A=0.0),
}


def run_variant(kw, mu_N=None, spectral=False):
    kw = dict(kw); kw.setdefault("beta", cfg["beta"])
    W = Walk(g, **kw)
    out, tt = [], 0.0
    for t in hours:
        L, R, cw = P.hour(t)
        t0 = time.perf_counter(); W.run(L, R, cw, fast=True); tt += time.perf_counter() - t0
        out.append(W.run(L, R, cw, spectral=spectral))
    return out, tt / len(hours)


def sp(a, b):
    return float(spearmanr(a, b).statistic)


def calib_eval(x, y, train, test):
    """Isotonic map indicator -> EENS on train hours, evaluated on held-out hours."""
    iso = IsotonicRegression(out_of_bounds="clip", increasing=True).fit(x[train], y[train])
    yh = iso.predict(x[test]); yt = y[test]
    k = max(1, int(0.1 * len(yt)))
    top_true = set(np.argsort(yt)[-k:]); top_pred = set(np.argsort(yh)[-k:])
    return dict(rel_err_total=float((yh.sum() - yt.sum()) / yt.sum()),
                spearman_test=sp(yh, yt), top10_hit=len(top_true & top_pred) / k)


idx = np.arange(len(hours)); train, test = idx % 2 == 0, idx % 2 == 1

# ---- hyper-parameters (mu_N, J0, tau) selected on TRAIN hours only ----
HP = [P.hour(t) for t in hours]
grid_mu = [0.3, 1, 3, 10, 30, 100, 300, 1000, 3000, 10000]
search = []
for mN in grid_mu:
    for J0 in [0.0, 0.1, 0.3, 1.0]:
        for tau in [0.5, 1.0, 2.0]:
            W = Walk(g, mu_N=mN, J0=max(J0, 1e-12), use_J=J0 > 0, tau=tau, n_t=21, beta=cfg["beta"])
            D = np.array([W.run(L, R, c, fast=True)["D"] for L, R, c in HP])
            search.append(dict(mu_N=mN, J0=J0, tau=tau, train=sp(D[train], T.EENS_tot[train]),
                               test=sp(D[test], T.EENS_tot[test])))
S = pd.DataFrame(search); S.to_csv(f"results/hyper_search_{case}.csv", index=False)
bw = S[S.J0 > 0].sort_values("train").iloc[-1]; b0 = S[S.J0 == 0].sort_values("train").iloc[-1]
HPW = dict(mu_N=float(bw.mu_N), J0=float(bw.J0), tau=float(bw.tau), n_t=21)
HP0 = dict(mu_N=float(b0.mu_N), use_J=False, tau=float(b0.tau), n_t=21)
print(f"[{case}] selected (train) walk: {HPW}  |  J=0: {HP0}")
VARIANTS = {
    "walk (full, J>0)":       HPW,
    "no hopping (J=0)":       HP0,
    "walk, uniform psi(0)":   dict(HPW, init="uniform"),
    "walk, adequacy term only": dict(HPW, mu_N=0.0),
    "walk, network term only":  dict(HPW, mu_A=0.0),
}
mu_N = HPW["mu_N"]

results, store = [], {}
for name, kw in VARIANTS.items():
    o, tsec = run_variant(kw, spectral=(name == "walk (full, J>0)"))
    D = np.array([q["D"] for q in o]); store[name] = o
    rec = dict(variant=name, ms_per_hour=1e3 * tsec,
               rho_EENS_tot=sp(D, T.EENS_tot), rho_LOLP=sp(D, T.LOLP_gen),
               rho_CS=sp(D, T.CS))
    rec.update(calib_eval(D, T.EENS_tot.values, train, test))
    results.append(rec)

# ---- channel-specific checks on the full walk ----
full = store["walk (full, J>0)"]
DA = np.array([q["DA"] for q in full]); DN = np.array([q["DN"] for q in full])
dom = np.array([q["dom_decay"] for q in full]); gap = np.array([q["gap"] for q in full])
z = np.array([q["z"] for q in full]); eta = np.array([q["eta_sum"] for q in full])

# ---- cheap classical baselines (no walk) ----
base = {
    "net load (L-R)": np.array([(lambda L, R, c: L.sum() - R.sum())(*P.hour(t)) for t in hours]),
    "normal-approx LOLP Phi(-z)": norm.cdf(-z),
    "N-1 overload sum (no walk)": eta,
    "static sum w_i*gamma_i (tau->0)": np.array([float(q["gamma"] @ (P.hour(t)[0] / P.hour(t)[0].sum()))
                                       for q, t in zip(full, hours)]),
}
for name, x in base.items():
    rec = dict(variant="BASELINE: " + name, ms_per_hour=np.nan,
               rho_EENS_tot=sp(x, T.EENS_tot), rho_LOLP=sp(x, T.LOLP_gen), rho_CS=sp(x, T.CS))
    rec.update(calib_eval(x, T.EENS_tot.values, train, test))
    results.append(rec)

R = pd.DataFrame(results)
chan = dict(rho_DA_LOLPgen=sp(DA, T.LOLP_gen), rho_DA_EENSgen=sp(DA, T.EENS_gen),
            rho_DN_CS=sp(DN, T.CS), rho_DN_EENScasc=sp(DN, T.EENS_casc),
            rho_domdecay_EENS=sp(dom, T.EENS_tot), rho_gap_EENS=sp(gap, T.EENS_tot),
            norm_identity_max_err=float(np.max(np.abs((1 - np.array([q["Psurv"] for q in full])) - (DA + DN)))))

# ---- node-level vulnerability ranking vs node cascade losses (MC/cascade) ----
# (generation-adequacy shedding location is degenerate in the LP, so node ranking
#  is validated on the cascading channel, where the loss location is physical)
V = np.mean([q["VN"] for q in full], axis=0)
V0 = np.mean([q["eta"] for q in full], axis=0)
nh = store["no hopping (J=0)"]; VJ0 = np.mean([q["VN"] for q in nh], axis=0)
node_mc = np.mean([r["node_EENS_casc"] for r in rows], axis=0)
loadbus = g.Pd_peak > 0
chan["rho_node_VN_walk_vs_cascade"] = sp(V[loadbus], node_mc[loadbus])
chan["rho_node_VN_noJ_vs_cascade"] = sp(VJ0[loadbus], node_mc[loadbus])
chan["rho_node_eta_vs_cascade"] = sp(V0[loadbus], node_mc[loadbus])
chan["rho_node_load_vs_cascade"] = sp(g.Pd_peak[loadbus], node_mc[loadbus])
k = max(1, int(round(0.2 * loadbus.sum())))
top = lambda x: set(np.argsort(x[loadbus])[-k:])
chan["top20pct_nodes_hit_walk"] = len(top(V) & top(node_mc)) / k
chan["top20pct_nodes_hit_noJ"] = len(top(VJ0) & top(node_mc)) / k
chan["top20pct_nodes_hit_load"] = len(top(g.Pd_peak) & top(node_mc)) / k
chan["selected_walk"] = HPW; chan["selected_J0"] = HP0
chan["classical_sec_per_hour"] = float(T.sec.mean())
chan["walk_ms_per_hour"] = float(R.iloc[0].ms_per_hour)
chan["annual_LOLE_h"] = float(T.LOLP_gen.mean() * 8760)
chan["annual_EENS_MWh"] = float(T.EENS_tot.mean() * 8760)

pd.set_option("display.width", 200)
print(R.round(3).to_string(index=False))
print(json.dumps({k: (round(v, 4) if isinstance(v, float) else v) for k, v in chan.items()}, indent=1))
R.to_csv(f"results/validation_{case}.csv", index=False)
json.dump(chan, open(f"results/channels_{case}.json", "w"), indent=1)
T["D"] = [q["D"] for q in full]; T["DA"] = DA; T["DN"] = DN; T["dom_decay"] = dom; T["gap"] = gap
T.to_csv(f"results/hourly_{case}.csv", index=False)
np.save(f"results/nodeV_{case}.npy", np.c_[V, VJ0, V0, node_mc, g.Pd_peak])
