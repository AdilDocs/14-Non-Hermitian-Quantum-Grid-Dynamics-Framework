"""
data.py - OPSD Germany 2018 hourly profiles mapped onto a test network.

Load:   L_i(t) = Pd_peak_i * L_DE(t) / max_t L_DE(t)
Wind:   W_i(t) = C_w,i * cf_w(t),  cf_w = DE wind generation / DE wind capacity
Solar:  S_i(t) = C_s,i * cf_s(t),  cf_s = DE solar generation / DE solar capacity
Wind plants are sited at the lowest-load buses (remote), PV at the highest-load
buses (distributed, near demand). Capacities are fractions of system peak load.
"""
import os
import numpy as np
import pandas as pd

OPSD = os.environ.get("OPSD_CSV", os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "time_series_60min_singleindex.csv"))
COLS = ["utc_timestamp", "DE_load_actual_entsoe_transparency",
        "DE_solar_generation_actual", "DE_solar_capacity",
        "DE_wind_generation_actual", "DE_wind_capacity"]


def load_opsd(year=2018, path=OPSD):
    df = pd.read_csv(path, usecols=COLS, parse_dates=["utc_timestamp"])
    df = df[df.utc_timestamp.dt.year == year].reset_index(drop=True)
    df = df.interpolate(limit_direction="both")
    out = pd.DataFrame({
        "ts": df.utc_timestamp,
        "load_pu": df.DE_load_actual_entsoe_transparency / df.DE_load_actual_entsoe_transparency.max(),
        "cf_wind": (df.DE_wind_generation_actual / df.DE_wind_capacity).clip(0, 1),
        "cf_solar": (df.DE_solar_generation_actual / df.DE_solar_capacity).clip(0, 1),
    })
    return out


class Profiles:
    def __init__(self, grid, opsd, wind_pen=0.35, solar_pen=0.20, n_wind=None, n_solar=None):
        self.g, self.d = grid, opsd
        N = grid.N
        n_wind = n_wind or max(2, N // 8)
        n_solar = n_solar or max(2, N // 6)
        peak = grid.Pd_peak.sum()
        order = np.argsort(grid.Pd_peak, kind="stable")
        self.wind_bus = order[:n_wind]
        self.solar_bus = order[::-1][:n_solar]
        self.Cw = np.zeros(N); self.Cw[self.wind_bus] = wind_pen * peak / n_wind
        self.Cs = np.zeros(N)
        w = grid.Pd_peak[self.solar_bus]
        self.Cs[self.solar_bus] = solar_pen * peak * w / w.sum()
        self.T = len(opsd)
        if getattr(grid, 'synthetic_rating', False):
            grid.envelope_ratings(self)

    def hour(self, t):
        r = self.d.iloc[t]
        L = self.g.Pd_peak * r.load_pu
        R = self.Cw * r.cf_wind + self.Cs * r.cf_solar
        return L, R, float(r.cf_wind)
