"""
walk.py - Single-excitation non-Hermitian quantum walk stress indicator.

Model (exact restriction of the N_b-qubit XY model to the one-excitation sector):

    H_real = sum_i B_i |i><i| + sum_(ij) J_ij (|i><j| + |j><i|)
           = P_1 [ sum_i B_i (I - Z_i)/2 + 1/2 sum J_ij (X_i X_j + Y_i Y_j) ] P_1
    Gamma  = sum_i gamma_i n_i,  n_i = (I - Z_i)/2 = |1><1|_i      (PSD, gamma_i >= 0)
    H      = H_real - i Gamma

Because XX+YY and n_i conserve the excitation number, the dynamics started in
the one-excitation sector stay there exactly, so the Hilbert space has
dimension N_b (not 2^N_b). Since Gamma >= 0:

    d/dt ||psi||^2 = -2 <psi|Gamma|psi> <= 0       (monotone norm decay)

IMPORTANT: gamma_i is built ONLY from stress quantities available without
sampling or optimisation (expected-capacity margin, DC flows of an expected
dispatch, LODF-based N-1 post-contingency loadings). It never uses the
classical ENS/LOLP ground truth.
"""
import numpy as np
import scipy.sparse as sp
import scipy.sparse.linalg as spla


def softplus(x):
    return np.logaddexp(0.0, x)


class Walk:
    def __init__(self, g, mu_A=1.0, mu_N=1.0, kappa=0.5, J0=1.0, tau=1.0,
                 theta=0.9, beta=9.0, n_t=11, use_J=True, init="load"):
        self.g = g
        self.mu_A, self.mu_N, self.kappa, self.J0, self.tau = mu_A, mu_N, kappa, J0, tau
        self.theta, self.beta, self.n_t, self.init = theta, beta, n_t, init
        # hopping operator from branch susceptances (parallel branches add)
        bn = np.abs(g.b) / np.abs(g.b).mean()
        J = sp.coo_matrix((bn, (g.fr, g.to)), shape=(g.N, g.N)).tocsr()
        self.J = (J + J.T) * (J0 if use_J else 0.0)
        self.sigC = np.sqrt(np.sum(g.upmax ** 2 * g.uA * (1 - g.uA)))
        self.capE = g.uA * g.upmax
        self.valid_k = ~g.radial

    # ------------------------------------------------------------ stresses
    def stresses(self, L, R, cf_w):
        g = self.g
        Rn = R * min(1.0, L.sum() / max(R.sum(), 1e-9))           # curtail RES surplus
        net = L - Rn
        z = (self.capE.sum() - net.sum()) / self.sigC              # standardised margin
        phiA = softplus(-z)
        w = L / L.sum()
        inj = g.merit_dispatch(net)
        f = g.flows(inj)
        # N-1 post-contingency loadings via LODF (l x k)
        post = np.abs(f[:, None] + g.LODF * f[None, :]) / g.F[:, None]
        np.fill_diagonal(post, 0.0)
        post = post[:, self.valid_k]
        lam = g.lam_line[self.valid_k] * (1 + self.beta * cf_w ** 2)
        pi = lam / lam.sum()
        rho = np.maximum(0.0, post - self.theta) @ pi              # expected N-1 overload per line
        eta = np.zeros(g.N)
        np.add.at(eta, g.fr, 0.5 * rho); np.add.at(eta, g.to, 0.5 * rho)
        return dict(phiA=phiA, z=z, w=w, eta=eta, inj=inj, rho=rho,
                    load0=np.abs(f) / g.F)

    # ------------------------------------------------------------ dynamics
    def operator(self, L, R, cf_w):
        """Single-excitation Hamiltonian H = diag(B) + J - i diag(gamma), initial state, parts."""
        g = self.g
        s = self.stresses(L, R, cf_w)
        gamma_A = self.mu_A * s["w"] * s["phiA"] * g.N              # node adequacy damping
        gamma_N = self.mu_N * s["eta"]                              # node network damping
        gamma = gamma_A + gamma_N                                   # >= 0  -> Gamma PSD
        u = s["inj"] / (np.abs(s["inj"]).mean() + 1e-9)
        H = (sp.diags(self.kappa * u) + self.J - 1j * sp.diags(gamma)).tocsc()
        if self.init == "load":
            psi0 = np.sqrt(s["w"]).astype(complex)
        else:
            psi0 = np.ones(g.N, complex) / np.sqrt(g.N)
        return H, psi0, gamma, gamma_A, gamma_N, s

    def run(self, L, R, cf_w, spectral=False, fast=False):
        g = self.g
        H, psi0, gamma, gamma_A, gamma_N, s = self.operator(L, R, cf_w)
        if fast:                                                   # indicator only (endpoint)
            psiT = spla.expm_multiply(-1j * self.tau * H, psi0)
            return dict(D=float(-np.log(np.vdot(psiT, psiT).real)))
        # time grid fine enough to resolve the fastest decay (for the channel split)
        n_t = int(min(400, max(self.n_t, np.ceil(20 * self.tau * gamma.max()) + 1)))
        ts = np.linspace(0, self.tau, n_t)
        traj = spla.expm_multiply(-1j * H, psi0, start=0, stop=self.tau,
                                  num=n_t, endpoint=True)             # (n_t, N)
        pop = np.abs(traj) ** 2
        norm2 = pop.sum(1)
        V = 2 * np.trapezoid(pop * gamma[None, :], ts, axis=0)    # node vulnerability
        VN = 2 * np.trapezoid(pop * gamma_N[None, :], ts, axis=0)  # network-channel node vulnerability
        out = dict(D=float(-np.log(norm2[-1])),                    # effective decay (indicator)
                   Psurv=float(norm2[-1]), V=V, VN=VN, gamma=gamma, eta=s["eta"],
                   DA=float(2 * np.trapezoid(pop @ gamma_A, ts)),  # adequacy share of decay
                   DN=float(2 * np.trapezoid(pop @ gamma_N, ts)),  # network share of decay
                   z=s["z"], phiA=s["phiA"], eta_sum=float(s["eta"].sum()))
        if spectral:
            if g.N <= 400:
                ev = np.linalg.eigvals(H.toarray())
            else:
                ev = np.r_[spla.eigs(H, k=6, which="SI", return_eigenvectors=False),
                           spla.eigs(H, k=2, which="SR", return_eigenvectors=False)]
            out["dom_decay"] = float(-ev.imag.min())
            Er = np.sort(ev.real)
            out["gap"] = float(Er[1] - Er[0])
        return out
