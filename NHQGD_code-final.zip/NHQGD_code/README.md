# NHQGD: Quantum-Inspired Non-Hermitian Framework for Reliability Screening

Code and results for the paper on sampling-free reliability screening of renewable-dominated
power systems with a non-Hermitian quantum walk (NHQGD).

## 1. Setup
```
pip install -r requirements.txt
```
Download the OPSD **Time series** data package (version 2020-10-06), file
`time_series_60min_singleindex.csv`, from https://doi.org/10.25832/time_series/2020-10-06
and place it in `data/` — or set `OPSD_CSV=/path/to/file.csv`.

## 2. Run everything
```
./runall.sh
```
All outputs are written to `results/` and `results/figs/`. The `results/` folder already
contains the outputs used in the paper, so figures can be regenerated without re-running the
benchmark: `python make_figures.py && python fig_setup.py`.

## 3. Files
| File | Paper section | Role |
|---|---|---|
| `grid.py` | III-A (Layer 1) | Test cases (pandapower), RTS-79 unit data, DC matrices (B, PTDF, LODF), rating synthesis |
| `data.py` | III-A, IV-B | OPSD Germany 2018 load, wind and solar profiles mapped to buses |
| `walk.py` | III-A/B/C (Layers 1–3) | Stress measures (z, phi_A, LODF N-1 overload), single-excitation non-Hermitian walk, PSD dissipation, D(t), D_A/D_N, V_i, spectrum |
| `classical.py` | IV-C | Independent benchmark: MCS + DC-OPF load shedding; N-1 DC cascade (tripping, islanding, rebalancing) |
| `run_groundtruth.py` | IV-C | Parallel benchmark runner -> `results/gt_<case>.pkl` |
| `validate.py` | IV-E…J | Train/test split, hyper-parameter search, held-out metrics, ablations, baselines, calibration |
| `combined_baseline.py` | IV-I | Rank-average combination of the classical baselines |
| `extra_experiments.py` | IV-D, IV-G | MC convergence and highest net-load week (24-bus) |
| `run_scaling.py` | IV-K | Runtime vs network size (24–2869 buses) |
| `make_figures.py`, `fig_setup.py` | IV | All 10 figures |

## 4. Final settings (as reported in the paper)
- Conventional capacity = annual peak load; wind 35 % and solar 20 % of peak.
- Units split to <= 400 MW, RTS-79 FOR/MTTR by size class (24-bus: exact RTS data, 32 units).
- Branch failure rate 0.5 /yr, weather factor lambda(t) = lambda0 (1 + 9 c_w^2); trip at 1.2 x rating.
- 118/300-bus ratings = 2.5 x yearly merit-order flow envelope (no limits in source data).
- Walk fixed parameters: mu_A = 1, kappa = 0.5, theta = 0.9, load-weighted initial state;
  mu_N, J0, tau selected on training hours (alternate-hour split).

## 5. Key results (held-out hours)
| | 24-bus | 118-bus | 300-bus |
|---|---|---|---|
| Spearman correlation with benchmark EENS | 0.93 | 0.68 | 0.61 |
| Top-10 % risk-hour detection | 97 % | 80 % | 70 % |
| Error of total EENS (after calibration) | 0.4 % | -4.9 % | 4.9 % |

Runtime: 36x (24-bus) to 2104x (2869-bus) faster than a classical lower bound
(one DC-OPF + all N-1 cascade simulations, without Monte Carlo sampling).
