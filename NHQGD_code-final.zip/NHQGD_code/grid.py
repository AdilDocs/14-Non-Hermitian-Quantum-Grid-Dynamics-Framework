"""
grid.py - Network, component-availability and DC sensitivity layer.

Loads IEEE / PEGASE test cases (via pandapower -> MATPOWER arrays), builds
unit-level generator availability data (RTS-79 for the IEEE 24-bus system,
size-class RTS-79 values otherwise), branch failure data, and the DC
sensitivity matrices (B, PTDF, LODF) used by both the classical ground truth
and the non-Hermitian walk indicator.
"""
import warnings
import numpy as np
import scipy.sparse as sp
import scipy.sparse.linalg as spla
from scipy.sparse.csgraph import connected_components

warnings.filterwarnings("ignore")

# RTS-79 unit reliability data by rated size (MW): (FOR, MTTR h)
RTS79_UNITS = {12: (0.02, 60), 20: (0.10, 50), 50: (0.01, 20), 76: (0.02, 40),
               100: (0.04, 50), 155: (0.04, 40), 197: (0.05, 50),
               350: (0.08, 100), 400: (0.12, 150)}
_SIZES = np.array(sorted(RTS79_UNITS))


def _unit_class(p):
    return int(_SIZES[np.argmin(np.abs(_SIZES - p))])


class Grid:
    """DC network model with unit-level availability data."""

    def __init__(self, case="case24_ieee_rts", reserve_margin=0.20,
                 rating_factor=1.3, max_unit_mw=400.0,
                 line_lambda=0.5, line_mttr=10.0, seed=0, env_factor=2.5):
        import pandapower.networks as pn
        from pandapower.converter.pypower.to_ppc import to_ppc
        import contextlib, io
        with contextlib.redirect_stdout(io.StringIO()):
            net = getattr(pn, case)()
            ppc = to_ppc(net, init="flat")
        self.case = case
        self.env_factor = env_factor
        self.base = float(ppc["baseMVA"])
        bus, br, gen = (ppc["bus"].real, ppc["branch"].real, ppc["gen"].real)
        idx = {int(b): k for k, b in enumerate(bus[:, 0])}
        self.N = len(bus)

        # ---- branches (in-service only) ----
        br = br[br[:, 10] > 0]
        tap = np.where(br[:, 8] == 0, 1.0, br[:, 8])
        x = br[:, 3] * tap
        x = np.where(np.abs(x) < 1e-5, 1e-5, x)
        self.fr = np.array([idx[int(b)] for b in br[:, 0]])
        self.to = np.array([idx[int(b)] for b in br[:, 1]])
        keep = self.fr != self.to
        self.fr, self.to, x, rate = self.fr[keep], self.to[keep], x[keep], br[keep, 5]
        self.L = len(x)
        self.b = 1.0 / x                                   # series susceptance (pu)

        # ---- loads ----
        self.Pd0 = np.clip(bus[:, 2], 0, None)             # MW, base-case peak share

        # ---- generators -> units ----
        gen = gen[gen[:, 7] > 0]
        cost_rows = ppc.get("gencost")
        units_bus, units_pmax, units_cost = [], [], []
        for k, g in enumerate(gen):
            pmax = g[8]
            if pmax <= 0.5:
                continue
            c = 20.0
            if cost_rows is not None and k < len(cost_rows):
                row = cost_rows[k].real
                n = int(row[3]); coefs = row[4:4 + n]
                if n >= 2:
                    c = float(coefs[-2] + (2 * coefs[-3] * pmax if n >= 3 else 0.0))
            nu = int(np.ceil(pmax / max_unit_mw - 1e-6))
            for _ in range(nu):
                units_bus.append(idx[int(g[0])]); units_pmax.append(pmax / nu)
                units_cost.append(c)
        self.ubus = np.array(units_bus)
        self.upmax = np.array(units_pmax)
        rng = np.random.default_rng(seed)
        self.ucost = np.array(units_cost) + rng.uniform(0, 0.5, len(units_cost))  # tie-break
        cls = [_unit_class(p) for p in self.upmax]
        self.ufor = np.array([RTS79_UNITS[c][0] for c in cls])
        self.umttr = np.array([RTS79_UNITS[c][1] for c in cls])
        self.uA = 1.0 - self.ufor                          # A_g = mu/(lambda+mu)
        self.G = len(self.upmax)

        # load scaling so that installed conventional capacity = (1+R) * peak
        self.alpha = self.upmax.sum() / ((1 + reserve_margin) * self.Pd0.sum())
        self.Pd_peak = self.alpha * self.Pd0

        # ---- branch failure data (per year, hours) ----
        self.lam_line = np.full(self.L, line_lambda)
        self.mttr_line = np.full(self.L, line_mttr)

        # ---- DC matrices ----
        self.ref = int(np.argmax(np.bincount(self.ubus, weights=self.upmax,
                                             minlength=self.N)))
        self.Cf = sp.csr_matrix((np.r_[np.ones(self.L), -np.ones(self.L)],
                                 (np.r_[np.arange(self.L), np.arange(self.L)],
                                  np.r_[self.fr, self.to])), shape=(self.L, self.N))
        self._build_ptdf()

        # ---- ratings ----
        bad = (rate <= 0) | (rate >= 9000)
        self.synthetic_rating = bool(bad.mean() > 0.5)
        if self.synthetic_rating:   # case has no meaningful thermal limits -> synthesize
            f = self.flows(self.proportional_dispatch(self.Pd_peak))
            fl = np.abs(f)
            floor = np.percentile(rating_factor * fl, 30)
            rate = np.maximum(rating_factor * fl, floor)
        else:
            f = self.flows(self.proportional_dispatch(self.Pd_peak))
            rate = np.where(bad, np.maximum(rating_factor * np.abs(f), np.median(rate[~bad])), rate)
        self.F = np.maximum(rate, 1.0)

    # ------------------------------------------------------------------ DC
    def Bbus(self, alive=None):
        b = self.b if alive is None else self.b * alive
        Bf = sp.diags(b) @ self.Cf
        return (self.Cf.T @ Bf).tocsc(), Bf

    def _build_ptdf(self):
        B, Bf = self.Bbus()
        nonref = np.setdiff1d(np.arange(self.N), [self.ref])
        Bred = B[nonref][:, nonref].tocsc()
        if self.N <= 3000:
            Binv = np.zeros((self.N, self.N))
            Binv[np.ix_(nonref, nonref)] = np.linalg.inv(Bred.toarray())
            self.PTDF = np.asarray(Bf @ Binv)              # L x N (MW flow per MW injection)
        self.Bred_lu = spla.splu(Bred)
        self.nonref = nonref
        # LODF: flow change on l per pre-outage flow on k
        Cft = self.Cf.toarray()
        H = self.PTDF @ Cft.T                              # L x L (PTDF of k's terminals)
        denom = 1.0 - np.diag(H)
        radial = np.abs(denom) < 1e-6
        denom[radial] = np.inf                             # islanding outage -> handled by cascade
        self.LODF = H / denom[None, :]
        np.fill_diagonal(self.LODF, -1.0)
        self.radial = radial

    def flows(self, inj):
        """Branch flows (MW) for a nodal injection vector (MW), intact topology."""
        return self.PTDF @ inj

    def proportional_dispatch(self, net_load, cap=None):
        """Dispatch generation proportional to (expected) capacity to meet net load."""
        cap = self.upmax if cap is None else cap
        tot = net_load.sum()
        share = cap / cap.sum()
        pg = share * min(tot, cap.sum())
        inj = -net_load.astype(float).copy()
        np.add.at(inj, self.ubus, pg)
        inj[self.ref] -= inj.sum()                         # slack residual
        return inj

    def envelope_ratings(self, profiles, factor=None, step=97, pct_floor=30):
        """Synthesize thermal ratings for cases without limits: factor x the yearly
        envelope of |flow| under merit-order dispatch (sampled hours)."""
        factor = self.env_factor if factor is None else factor
        fmax = np.zeros(self.L)
        for t in range(0, profiles.T, step):
            L, R, _ = profiles.hour(t)
            Rn = R * min(1.0, L.sum() / max(R.sum(), 1e-9))
            fmax = np.maximum(fmax, np.abs(self.flows(self.merit_dispatch(L - Rn))))
        r = factor * fmax
        self.F = np.maximum(r, np.percentile(r, pct_floor))

    def merit_dispatch(self, net_load, cap=None):
        """Merit-order (unconstrained economic) dispatch -> nodal injections."""
        cap = self.upmax if cap is None else cap
        need = max(0.0, net_load.sum())
        pg = np.zeros(self.G)
        for u in np.argsort(self.ucost):
            take = min(cap[u], need); pg[u] = take; need -= take
            if need <= 0: break
        inj = -net_load.astype(float).copy()
        np.add.at(inj, self.ubus, pg)
        inj[self.ref] -= inj.sum()
        return inj

    # --------------------------------------------- islands & general topology
    def dc_flows_topology(self, inj, alive):
        """DC flows for arbitrary branch status; per-island balanced injections."""
        A = sp.csr_matrix((np.ones(alive.sum()), (self.fr[alive], self.to[alive])),
                          shape=(self.N, self.N))
        ncomp, lab = connected_components(A, directed=False)
        B, Bf = self.Bbus(alive.astype(float))
        theta = np.zeros(self.N)
        for c in range(ncomp):
            nodes = np.where(lab == c)[0]
            if len(nodes) == 1:
                continue
            nr = nodes[1:]
            Bc = B[nr][:, nr].tocsc()
            theta[nr] = spla.spsolve(Bc, inj[nr]) if len(nr) > 1 else inj[nr] / Bc.toarray()[0]
        return np.asarray(Bf @ theta).ravel(), ncomp, lab
