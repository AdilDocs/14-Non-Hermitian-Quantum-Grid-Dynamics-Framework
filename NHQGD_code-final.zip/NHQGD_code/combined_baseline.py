"""combined_baseline.py - rank-average / additive combination of the two classical baselines
(normal-approx LOLP and N-1 overload sum), weight selected on training hours."""
import sys, pickle, numpy as np, pandas as pd
from scipy.stats import spearmanr, norm, rankdata
from grid import Grid; from data import load_opsd, Profiles; from walk import Walk
for case in ["case24_ieee_rts","case118","case300"]:
    gt=pickle.load(open(f"results/gt_{case}.pkl","rb")); rows=gt["rows"]
    g=Grid(case,reserve_margin=0.0); P=Profiles(g,load_opsd()); W=Walk(g)
    y=np.array([r["EENS_tot"] for r in rows]); tr=np.arange(len(rows))%2==0
    z=[];eta=[]
    for r in rows:
        s=W.stresses(*P.hour(r["t"])); z.append(s["z"]); eta.append(s["eta"].sum())
    a=norm.cdf(-np.array(z)); n=np.array(eta)
    best=None
    for wgt in np.linspace(0,1,21):          # rank-average combination
        x=wgt*rankdata(a)+(1-wgt)*rankdata(n)
        st=spearmanr(x[tr],y[tr]).statistic
        if best is None or st>best[1]: best=(wgt,st,spearmanr(x[~tr],y[~tr]).statistic)
    best2=None
    for lw in np.linspace(-4,4,33):          # additive combination on raw scale: Phi(-z) + 10^lw * eta
        x=a+10**lw*n; st=spearmanr(x[tr],y[tr]).statistic
        if best2 is None or st>best2[1]: best2=(lw,st,spearmanr(x[~tr],y[~tr]).statistic)
    print(case,"rank-avg: w=%.2f train %.3f test %.3f"%best, "| additive: log10w=%.2f train %.3f test %.3f"%best2)
