"""
extra_experiments.py - data for supporting figures (IEEE 24-bus):
  (1) MC convergence: running EENS estimate vs number of samples for 3 hours
  (2) consecutive-week benchmark + indicator time series (highest net-load week)
Saves results/extra_case24.pkl
"""
import pickle, json, numpy as np
from grid import Grid
from data import load_opsd, Profiles
from classical import dispatch_lp, evaluate_hour
from walk import Walk

case = "case24_ieee_rts"
g = Grid(case, reserve_margin=0.0); P = Profiles(g, load_opsd())
hourly = __import__("pandas").read_csv(f"results/hourly_{case}.csv")
sel = json.load(open(f"results/channels_{case}.json"))["selected_walk"]


def per_sample_shed(t, Ns, seed=11):
    L, R, _ = P.hour(t)
    U = np.random.default_rng(seed).random((Ns, g.G)); avail = U < g.uA
    pg0, sh0, _ = dispatch_lp(g, L, R, g.upmax)
    supports = [pg0 > 1e-6] if sh0.sum() < 1e-6 else []
    cache = {}; out = np.zeros(Ns)
    for s in range(Ns):
        a = avail[s]
        if any(not np.any(sup & ~a) for sup in supports):
            continue
        k = a.tobytes()
        if k not in cache:
            pg, sh, _ = dispatch_lp(g, L, R, g.upmax * a); cache[k] = sh.sum()
            if sh.sum() < 1e-6 and len(supports) < 64: supports.append(pg > 1e-6)
        out[s] = cache[k]
    return out


# (1) three representative hours by benchmark generation EENS
nz = hourly[hourly.EENS_gen > 0].sort_values("EENS_gen")
reps = {"high": int(nz.t.iloc[-1]), "medium": int(nz.t.iloc[len(nz) // 2]), "low": int(nz.t.iloc[len(nz) // 10])}
conv = {k: per_sample_shed(t, 20000) for k, t in reps.items()}
print("convergence hours", reps)

# (2) highest mean net-load week (168 consecutive hours)
net = np.array([P.hour(t)[0].sum() - P.hour(t)[1].sum() for t in range(P.T)])
wk = np.convolve(net, np.ones(168), "valid"); t0 = int(np.argmax(wk))
hours = np.arange(t0, t0 + 168)
U = np.random.default_rng(0).random((4000, g.G))
W = Walk(g, **sel)
rows = []
for t in hours:
    L, R, cw = P.hour(t)
    r = evaluate_hour(g, L, R, cw, U, beta=9.0, trip_factor=1.2)
    o = W.run(L, R, cw)
    rows.append(dict(t=int(t), EENS=r["EENS_tot"], EENS_gen=r["EENS_gen"], EENS_casc=r["EENS_casc"],
                     CS=r["CS"], D=o["D"], DA=o["DA"], DN=o["DN"], net=float(L.sum() - R.sum())))
print("week start hour", t0)
pickle.dump(dict(reps=reps, conv=conv, week=rows, week_start=t0, ts=str(P.d.ts.iloc[t0])),
            open(f"results/extra_case24.pkl", "wb"))
print("done")
