"""Section IV figures: network maps with renewable siting, OPSD 2018 profiles, benchmark risk composition."""
import json, os, pickle
import numpy as np, pandas as pd, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
import pandapower.networks as pn
from grid import Grid
from data import load_opsd, Profiles

C = {"wind": "#1baf7a", "solar": "#eda100", "gen": "#2a78d6", "load": "#9b9a93", "casc": "#eb6834"}
INK, MUTED, GRID = "#000000", "#000000", "#e4e3dc"
plt.rcParams.update({"font.family": "serif", "font.size": 9, "text.color": "#000000", "axes.titlecolor": "#000000", "legend.labelcolor": "#000000", "axes.linewidth": 0.9, "axes.edgecolor": MUTED, "axes.labelcolor": INK,
                     "xtick.color": MUTED, "ytick.color": MUTED, "axes.spines.top": False,
                     "axes.spines.right": False, "legend.frameon": False})
os.makedirs("results/figs", exist_ok=True)
d = load_opsd()


def save(fig, name):
    fig.tight_layout(); fig.savefig(f"results/figs/{name}.png", dpi=300); fig.savefig(f"results/figs/{name}.pdf"); plt.close(fig)


# ---------------- network maps ----------------
fig, axes = plt.subplots(1, 2, figsize=(7.2, 3.7))
for a, (case, title) in zip(axes, [("case24_ieee_rts", "(a) IEEE 24-bus RTS"), ("case118", "(b) IEEE 118-bus")]):
    net = getattr(pn, case)()
    xy = np.array([json.loads(s)["coordinates"] for s in net.bus.geo])
    g = Grid(case, reserve_margin=0.0); P = Profiles(g, d)
    lw = 0.4 + 2.2 * g.F / g.F.max()
    for l in range(g.L):
        i, j = g.fr[l], g.to[l]
        a.plot(xy[[i, j], 0], xy[[i, j], 1], color="#b9b8b0", lw=lw[l], zorder=1, solid_capstyle="round")
    size = (60 if case == 'case24_ieee_rts' else 14) + (150 if case == 'case24_ieee_rts' else 110) * g.Pd_peak / g.Pd_peak.max()
    genb = np.zeros(g.N, bool); genb[g.ubus] = True
    col = np.array([C["load"]] * g.N, dtype=object); col[genb] = C["gen"]
    col[P.solar_bus] = C["solar"]; col[P.wind_bus] = C["wind"]
    a.scatter(xy[:, 0], xy[:, 1], s=size, c=list(col), edgecolor="white", lw=0.6, zorder=3)
    if case == "case24_ieee_rts":
        for i in range(g.N):
            a.text(xy[i, 0], xy[i, 1], str(i + 1), fontsize=5.5, ha="center", va="center", color="white", zorder=4, fontweight="bold")
    a.set_title(title, fontsize=9, color=INK); a.set_aspect("equal"); a.axis("off")
leg = [Line2D([0], [0], marker="o", ls="", markerfacecolor=C[k], markeredgecolor="white", markersize=8, label=lab)
       for k, lab in [("wind", "wind plant"), ("solar", "solar plant"), ("gen", "conventional units"), ("load", "load bus")]]
leg.append(Line2D([0], [0], color="#b9b8b0", lw=2, label="branch (width ∝ rating)"))
fig.legend(handles=leg, loc="lower center", ncol=5, fontsize=7.5, bbox_to_anchor=(0.5, -0.01))
fig.text(0.5, 0.075, "Marker area increases with the peak bus load.", ha="center", fontsize=7.5, color=MUTED)
fig.tight_layout(rect=(0, 0.1, 1, 1)); fig.savefig("results/figs/fig_networks.png", dpi=300); fig.savefig("results/figs/fig_networks.pdf"); plt.close(fig)

# ---------------- OPSD 2018 profiles ----------------
x = d.copy(); x["day"] = x.ts.dt.dayofyear; x["hour"] = x.ts.dt.hour; x["month"] = x.ts.dt.month
dd = x.groupby("day")[["load_pu", "cf_wind", "cf_solar"]].agg(["mean", "min", "max"])
fig = plt.figure(figsize=(7.2, 4.6)); gs = fig.add_gridspec(3, 2, width_ratios=[2.3, 1])
labels = [("load_pu", "Normalized load", C["gen"]), ("cf_wind", "Wind capacity factor", C["wind"]), ("cf_solar", "Solar capacity factor", C["solar"])]
for r, (k, lab, col) in enumerate(labels):
    a = fig.add_subplot(gs[r, 0])
    a.fill_between(dd.index, dd[(k, "min")], dd[(k, "max")], color=col, alpha=0.18, lw=0)
    a.plot(dd.index, dd[(k, "mean")], color=col, lw=1.3)
    a.set_ylabel(lab, fontsize=8); a.grid(True, color=GRID, lw=0.5); a.set_xlim(1, 365)
    if r < 2: a.set_xticklabels([])
    else: a.set_xlabel("Day of year 2018")
    if r == 0: a.set_title("(a) Daily mean (line) and daily range (band)", fontsize=9, color=INK, loc="left")
# mean daily profile by season
a = fig.add_subplot(gs[:, 1])
seasons = {"winter": [12, 1, 2], "summer": [6, 7, 8]}
for k, lab, col in labels:
    for s, mon in seasons.items():
        prof = x[x.month.isin(mon)].groupby("hour")[k].mean()
        a.plot(prof.index, prof.values, color=col, lw=1.6, ls="-" if s == "winter" else "--")
a.set_xticks([0, 6, 12, 18, 23]); a.set_xlabel("Hour of day (UTC)"); a.set_ylabel("Mean value (p.u.)")
a.grid(True, color=GRID, lw=0.5); a.set_title("(b) Mean daily profile", fontsize=9, color=INK, loc="left")
a.legend(handles=[Line2D([0], [0], color=INK, lw=1.4, ls="-", label="winter"),
                  Line2D([0], [0], color=INK, lw=1.4, ls="--", label="summer")], loc="center right", fontsize=7.5)
save(fig, "fig_opsd_profiles")

# ---------------- benchmark risk composition (needs final ground truth) ----------------
cases = [("case24_ieee_rts", "24-bus"), ("case118", "118-bus"), ("case300", "300-bus")]
if all(os.path.exists(f"results/hourly_{c}.csv") for c, _ in cases):
    fig, ax = plt.subplots(1, 2, figsize=(7.2, 3.1), gridspec_kw={"width_ratios": [1.5, 1]})
    for k, (c, lab) in enumerate(cases):
        h = pd.read_csv(f"results/hourly_{c}.csv"); e = np.sort(h.EENS_tot.values)
        frac = 1 - np.arange(len(e)) / len(e)
        ax[0].step(np.clip(e, 1e-4, None), frac, where="post", color=["#2a78d6", "#eb6834", "#1baf7a"][k], lw=1.7, label=lab)
    ax[0].set_xscale("log"); ax[0].set_yscale("log"); ax[0].grid(True, color=GRID, lw=0.5)
    ax[0].set_xlabel("Hourly benchmark EENS (MWh/h)"); ax[0].set_ylabel("Fraction of hours exceeding")
    ax[0].set_title("(a) Exceedance of hourly risk", fontsize=9, color=INK, loc="left"); ax[0].legend(fontsize=7.5, loc="lower left")
    gen = []; casc = []
    for c, _ in cases:
        h = pd.read_csv(f"results/hourly_{c}.csv"); tot = h.EENS_tot.sum()
        gen.append(100 * h.EENS_gen.sum() / tot); casc.append(100 * h.EENS_casc.sum() / tot)
    yy = np.arange(len(cases))
    ax[1].barh(yy, gen, color=C["gen"], height=0.55, label="generation adequacy")
    ax[1].barh(yy, casc, left=gen, color=C["casc"], height=0.55, label="cascading outages")
    for i in range(len(cases)):
        ax[1].text(gen[i] + casc[i] - 1, i, f"{casc[i]:.0f}%", va="center", ha="right", fontsize=7.5, color="white")
    ax[1].set_yticks(yy, [l for _, l in cases]); ax[1].invert_yaxis(); ax[1].set_xlim(0, 100)
    ax[1].set_xlabel("Share of total EENS (%)"); ax[1].set_title("(b) Risk composition", fontsize=9, color=INK, loc="left")
    ax[1].legend(fontsize=7, loc="upper center", bbox_to_anchor=(0.5, -0.3), ncol=2, handlelength=1.2, columnspacing=0.8)
    save(fig, "fig_benchmark_risk")
print("setup figures done")
